import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { StockListWrapper } from "./StockList.styled";

const StockList = () => {
	const navigate = useNavigate();
	const [stocks, setStocks] = useState(null);
	useEffect(() => {
		const fetchData = async () => {
			try {
				const response = await fetch("http://127.0.0.1:3001/").then(res =>
					res.json()
				);
				setStocks(response);
			} catch (error) {
				console.error("Error fetching data: ", error);
			}
		};

		fetchData();
	}, []);

	const handleStockClick = number => {
		navigate(`/dashboard/stock/${number}`);
	};

	if (stocks === null) return <h2>Loading</h2>;
	return (
		<StockListWrapper>
			<h1 className="stock-list-title">Most Active Stocks NSE</h1>
			<div className="stock-list">
				{stocks.map(stock => (
					<div
						key={stock.number}
						className="stock-container"
						onClick={() => handleStockClick(stock.number)}
					>
						<div className="stock-name">{stock.name}</div>
						<div className="stock-value">Current Value: {stock.value}</div>
					</div>
				))}
			</div>
		</StockListWrapper>
	);
};

export default StockList;
