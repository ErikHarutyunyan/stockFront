import { Link } from "react-router-dom";
import { BannerWrapper } from "./Home.styled";

const Home = () => {
	return (
		<BannerWrapper className="banner banner--style1">
			<div className="banner__bg">
				<div className="banner__bg-element">
					<img
						src="https://thetork.com/demos/html/bitrader/assets/images/banner/home1/bg-dark.png"
						alt="section-bg-element"
					/>
				</div>
			</div>
			<div className="container">
				<div className="banner__wrapper">
					<div className="row gy-5 gx-4">
						<div className="col-6">
							<div
								className="banner__content aos-init aos-animate"
								data-aos="fade-right"
								data-aos-duration="1000"
							>
								<div className="banner__content-coin">
									<img
										src="https://thetork.com/demos/html/bitrader/assets/images/banner/home1/3.png"
										alt="coin icon"
									/>
								</div>
								<h1 className="banner__content-heading">
									Invest your money with <span>higher return</span>
								</h1>
								<p className="banner__content-sub-heading">
									Anyone can invest money to different currency to increase
									their earnings by the help of Bitrader through online.
								</p>
								<div className="banner__btn-group btn-group">
									<Link to={"/login"} className="primary">
										Get Started
									</Link>
								</div>
							</div>
						</div>
						<div className="col-6">
							<div
								className="banner__thumb aos-init aos-animate"
								data-aos="fade-left"
								data-aos-duration="1000"
							>
								<img
									src="https://thetork.com/demos/html/bitrader/assets/images/banner/home1/1-dark.png"
									alt="banner-thumb"
									className="dark"
								/>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className="banner__shape">
				<span className="banner__shape-item banner__shape-item--1">
					<img
						src="https://thetork.com/demos/html/bitrader/assets/images/banner/home1/4.png"
						alt="shape icon"
					/>
				</span>
			</div>
		</BannerWrapper>
	);
};

export default Home;
